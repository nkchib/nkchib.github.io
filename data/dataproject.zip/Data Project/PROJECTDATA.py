'''
####################################
Name: Seth Chairez and Nicholas Chib
Period 2
AP CSP
2/6/17
####################################
'''

import PIL
import matplotlib.pyplot as plt
import os.path
import numpy as np

def style(axes):
    for item in ([axes.title, axes.xaxis.label, axes.yaxis.label] +
             axes.get_xticklabels() + axes.get_yticklabels()):
        item.set_family('Comic Sans MS')
        item.set_fontsize(16)
        
directory = os.path.dirname(os.path.abspath(__file__))
# Build an absolute filename from directory + filename
shark_file = os.path.join(directory, 'shark.png')
filename = os.path.join(directory, 'CurrencyExchangeRates.csv')
datafile = open(filename,'r')
data = datafile.readlines()
#all the lists for each currency
years = []
value = []
years_pound = []
value_pound = []
years_yen = []
value_yen = []
years_franc = []
value_franc = []
years_cd = []
value_cd = []

for line in data:
    #splits each individual part by a comma in the csv file
    currency, year, money = line.split(',')
    
    if currency == 'EURO':
            # Add the x and y values to the lists
            years.append(year)
            value.append(money)
    elif currency == "POUND":
        years_pound.append(year)
        value_pound.append(money)
    elif currency == "YEN":
        years_yen.append(year)
        value_yen.append(money)
    elif currency == "FRANC":
        years_franc.append(year)
        value_franc.append(money)
    elif currency == "CANADIAN DOLLAR":
        years_cd.append(year)
        value_cd.append(money)            
    datafile.close()

    
     
shark_img = PIL.Image.open(shark_file)        
fig_size, ax  = plt.subplots(1, 2)
ax[1].imshow(shark_img, interpolation='none')
#Creates the line graph
ax[0].plot(years, value, color = 'blue')
ax[0].plot(years_pound, value_pound, color= 'green')
ax[0].plot(years_yen, value_yen, color = 'red')
ax[0].plot(years_franc, value_franc, color = 'lightblue')
ax[0].plot(years_cd, value_cd, color = 'magenta')
#limits the y and x axis
ax[0].set_xlim(2006, 2018)
ax[0].set_ylim(0,3)
#labels the graph
ax[0].set_title('Currency Investment')
ax[0].set_xlabel('Time (Years)')
ax[0].set_ylabel('USD')
#creates the legend for the lines
pound, = plt.plot([1,2,3], label='Pound', color='green')
euro, = plt.plot([3,2,1], label='Euro', color='blue')
yen, = plt.plot([3,2,1], label='Yen', color='red')
franc, = plt.plot([3,2,1], label='Franc', color='lightblue')
cd, = plt.plot([3,2,1], label='Candaian Dollar', color='magenta')
ax[0].legend(handles=[pound, euro, yen, franc, cd])
plt.show()